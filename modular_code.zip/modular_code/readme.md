## **Project Overview**



Sales forecasting enables businesses to allocate resources for future growth while managing cash flow properly. Sales forecasting also assists firms in precisely estimating their expenditures and revenue, allowing them to predict their short- and long-term success. 

Retail Sales Forecasting also assists retailers in meeting customer expectations by better understanding consumer purchasing trends. This results in more efficient use of shelf and display space within the retail establishment and optimal use of inventory space.
The Bigmart sales forecast project can help you comprehend project creation in a professional atmosphere. This project entails extracting and processing data in the Amazon Redshift database before further processing and building various machine-learning models for sales prediction. 


We will study several data processing techniques, exploratory data analysis, and categorical correlation with Chi-squared, Cramer’s v tests, and ANOVA. In addition to basic statistical models like Linear Regression, we will learn how to design cutting-edge machine-learning models like Gradient Boosting and Generalized Additive Models. We will investigate splines and multivariate adaptive regression splines (MARS), as well as ensemble techniques like model stacking and model blending, and evaluate these models for the best results.



## **Execution Instructions**

* Create a python environment using the command 'python3 -m venv myenv'.

* Activate the environment by running the command 'myenv\Scripts\activate.bat'.

* Install the requirements using the command 'pip install -r requirements.txt'

* Run engine.py with the command 'python3 engine.py'.